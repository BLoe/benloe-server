# PLAYBOOK — what works on Ben

Cabinet-maintained. Each entry: hypothesis, evidence, status. Entries are
promoted/demoted from lesson data and weekly review. Seeded 2026-07 from
Ben's own account (status: hypothesis until behavior confirms).

## P1. Appointments beat intentions — by a mile
Scheduled + external + social = elite adherence. Self-generated structure
does not form.
Evidence: ~4 missed trainer sessions in 2 years; leagues never skipped;
Eagle Scout pipeline completed; camp staff summers; degree finished on
deadline crunch. Contrast: evenings collapsed when gaming's structure
vanished; diet has never had structure and never held.
Play: convert every goal into a scheduled appointment with a named time.
Add social stakes wherever possible (leagues, Zach/Jeff, trainer,
family). Cabinet is the appointment generator, not the willpower coach.

## P2. Drift-normalization is the failure mode to guard
Ben absorbs slowly degrading situations and rationalizes them; high crunch
talent means nothing forces a reckoning until the cost is large.
Evidence (his words): the startup, 3.5 years — "I let it get worse and
worse and convinced myself"; decade-long weight creep; rushed ankle
weight-bearing because it didn't hurt yet.
Play: Cabinet is the drift detector. Surface small trend deviations early
and concretely ("that's three weeks flat — plan needs a look") while
they're cheap. Never wait for Ben to notice.
Addendum (2026-07): drift has a twin — the CLIFF. The Feb–Jul collapse
(239→280) was not gradual: substances resumed → emotional hit (bad date)
→ social season + work crunch → tracking stopped → cascade. Watch for the
chain's early links, especially emotional hits; the days after a
disappointment are the highest-risk window on the calendar.

## P3. Deadline talent — give the week a finish line
Procrastinator who performs when there's a test. 
Play: structure weeks like matches: Sunday review is the whistle; give
each week one measurable headline target. Frame experiments with end
dates. Open loops with no deadline will silently die.

## P4. The evening war is won at 2pm
Loop: boredom + weed + frictionless food (Seamless, bodega downstairs).
By 10pm, decisions lose. Earlier, logistics win.
Play: default dinner locked by morning; counter-snack pre-stocked and
pre-portioned; afternoon protein snack ~3:30 to defuse the late spike;
evening block starts BEFORE the craving window (~7:30), not after. In the
moment: name one concrete move + 15-minute delay. Track which redirects
work; rank them here.

## P5. Weed timing is a schedulable variable
Currently entangled with the eating loop. 
Play: treat timing as the experiment surface (e.g., after dinner + after
evening block vs. before) and measure against snacking, sleep quality,
morning mood. Data, not editorials.

## P6. Identity levers that land
- Methodical/compounding: his self-image ("plodding, methodical pace").
  Frame all progress as compounding trend, never sprint.
- Reader: lifelong epic/literary fantasy. Books are the authentic wind-down;
  maintain the queue. YouTube→book is a substitution, not a subtraction.
- Team guy: shyness broke via groups (youth group, camp, leagues). Solo
  goals convert to shared formats where possible.
- Builder: evenings that involve making something (Cabinet itself, projects)
  are self-reinforcing and displace the rot loop.

## P7. Bright lines for influence
- Never shame; never disappointment-parent. Failure moments get damage
  control + optimism; causes get found later in counsel.
- Never invoke his father as a warning or scare tactic. Ben knows the
  stakes better than anyone. The parallel is context, not leverage.
- Dating is a slow-rebuild domain (two damaging relationships, then ~15
  intentionally single years — his own causal account). Support momentum;
  never gamify, never pressure, never treat it as a funnel.
  - The failure unit is the AFTERMATH, not the date: one mediocre date →
    months of withdrawal. The post-date debrief (counsel register, within
    a day or two) is where the cycle gets broken — process it, extract
    one lesson, keep it a data point instead of a verdict.
  - The dating-history question is preparable. His real facts told in
    sequence are an ascent story, not a losses story; help him build and
    practice the honest 30-second version before the next date, not after.
  - "Comfortable in my skin first" is partly real and partly a deferral
    risk. Don't push app volume now; DO set a re-entry marker Ben chooses
    (felt-based or a waypoint), and meanwhile buy confidence that's
    purchasable today — clothes that fit the current body. Waiting to
    deserve clothes is backwards.

## P8. Data framing lands
Engineer. Present changes as experiments with hypotheses and results;
show the trend math; give confidence bands. "Here's what the data says"
is more persuasive to Ben than any pep talk.

## P9. All-or-nothing is the enemy — design for graceful degradation
Feb 2026 proved Ben can run a perfect system; Feb–Jul proved a perfect
system is the wrong design. One crack (substances back, one bad night)
collapsed abstinence + tracking + diet simultaneously. The only survivor:
the trainer (external, scheduled, social).
Play: build FLOORS that survive any week — morning weigh-in, protein
floor, trainer, wind-down. A chaos day still gets one photo or one
sentence logged; the metric Cabinet protects is days-with-any-signal, not
perfect logs. A drinking weekend costs the weekend, never the system.
Collapse detection is fast (3 missed morning logs → reach out, warm, no
guilt) and re-entry is frictionless: no makeup work, no confession, the
trend line absorbs everything, day one just starts.

## P10. Hands busy, mouth idle
Evening activities that occupy the hands suppress grazing mechanically:
guitar practice, cooking, building. Fretwork and Grubhub don't coexist.
Prefer these in the MAIN BLOCK on high-risk evenings.
