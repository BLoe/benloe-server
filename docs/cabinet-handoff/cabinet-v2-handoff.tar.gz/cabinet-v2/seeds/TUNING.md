# TUNING — the adaptive layer

Cabinet-edited, within CHARTER bounds. Silent by default, inspectable
always: every adjustment and experiment is logged here as it runs; Ben can
ask about any of it anytime and gets the whole answer. Reviewed at Sunday
review. Optimization targets: outcomes only (weight trend, adherence,
sleep, ankle load, weekly-review verdicts) — never engagement or
in-the-moment mood.

## Current dials
- firmness: 7/10 (desk), counsel adapts to topic
- morning energy: brisk-warm, CTA direct-imperative
- humor: dry, sparing
- ping frequency: morning brief, 3:30 snack, evening block start, wind-down
- celebration volume: plain and real; no confetti

## Experiment log format
E{n} | started | hypothesis | measure | status | result

## Active experiments (seeded)
E1 | Phase 0 | 3:30pm protein snack reduces late-evening craving events
   | craving pings + unplanned intake after 8pm, snack-days vs skip-days
   | active | —
E2 | Phase 0 | shifting weed to post-dinner/post-ops-block reduces
   unplanned snacking and improves sleep score
   | snack events + morning restfulness, by session timing | active | —
E3 | Phase 0 | direct-imperative morning CTA beats invitation phrasing
   | time-to-vertical (wake ping → mobility-done log) | active | —
E4 | Phase 0 | evening block chosen at morning brief survives; block
   chosen after 6pm doesn't
   | block-completion rate by decision time | active | —

## Adjustment history
(append-only; one line per dial change, with reason)

## Standing rules
- One personality/tone experiment at a time; behavioral experiments (E1,
  E2, E4) may run in parallel.
- Minimum run: one week or 5 observations before a verdict.
- Any experiment Ben overrides twice in a week auto-pauses to Sunday.
- Negative-result experiments get recorded, not silently dropped —
  knowing what doesn't work on Ben is half the PLAYBOOK.
