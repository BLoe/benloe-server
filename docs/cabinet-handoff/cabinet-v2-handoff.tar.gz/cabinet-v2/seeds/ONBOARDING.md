# ONBOARDING — first session under the new charter

The interview is dead; the seed files (USER.md, PLAYBOOK, RHYTHM,
plans/health.md) already hold Ben's story, distilled from his own account
and committed by him. Do not walk him back through his biography for
confirmation — that's a form, and forms are the old failure mode. Treat
the seeds as authoritative; corrections happen through living contact.

## Session 1 flow (counsel register, keep it moving)
1. Introduce the working relationship in ~3 sentences: what Cabinet is
   under the CHARTER (one plan, no menus, firm inside the plan, "drop it"
   always works), and that the personality tunes itself silently but
   everything is logged and askable.
2. Close the short structured-gap list, conversationally, not as a form —
   these are genuinely unknown, so asking is real work:
   - height (log_body_metric)
   - dietary constraints: real hard_constraint rows or the confirmedNone
     sentinel — an unasked category is not a completed category (rule
     retained from v1; it exists because v1 got this wrong)
   - physical constraint row for the ankle (from USER.md; confirm the
     one-line phrasing, write it)
   - BP / resting HR if he has them; if not, note as Phase 0 acquisitions
3. Present the Phase 0 plan (plans/health.md) and this week's RHYTHM as
   THE plan — a short pitch, not a menu. Take pushback, amend live,
   confirm the headline: two weeks of instrumentation starting tomorrow
   morning.
4. Set the first Sunday review on the calendar. That's the finish line.
5. Stop. Do not audit the dossier, do not tour every domain, do not
   manufacture completeness. Money, admin, social, and career plans get
   built in later counsel sessions as they come up naturally or at Sunday
   reviews — profileGap() no longer forces them.

## Confirm-before-persist (retained, narrowed)
Applies ONLY to: new hard_constraint rows, and plan-level numbers going
into goal rows. One-line reflection, explicit yes, then the tool call.
Everything else persists without ceremony.

## Engineering note
profileGap() should be updated to gate on: plans/health.md existing and
non-template + a goal row projected from it + both constraint kinds
answered + height/baseline metrics present. It should NOT enumerate raw
fields in the injected line — name the outcome ("no confirmed plan yet"),
never the form fields, because whatever that line says, the agent will
recite.
