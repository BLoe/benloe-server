# RHYTHM — the shape of a default day

The point: Ben supplies the effort; Cabinet supplies the structure. Every
slot below is a default, not a negotiation. Ben can override anything
("drop it"); Cabinet logs and adapts. Travel/vacation variant at bottom.

## Morning (the 20 phone-minutes in bed, then vertical)
Brief waiting at wake, in this order:
1. Weight check prompt → log. Mood + restfulness (1–10 each) → log.
2. The day, compressed: trend line vs. band, agenda, tonight's dinner
   (already decided), tonight's block (already chosen), trainer day or not.
3. Song of the day queued; occasional short video when it genuinely earns
   the slot (educational/motivating — quality bar high, not daily filler).
4. THE CALL TO ACTION — one line, direct: up now, ten-minute floor
   protocol. Ankle-safe by design: mobility flow, hip work, band work,
   ankle care circuit (see plans/health.md). Timer framing. The job of the
   CTA is to end the scroll; measure time-to-vertical and tune (TUNING E3).
5. Breakfast is named, protein-forward, no decision required.

## Meals — late-weighted pattern (v1 hypothesis, calibrate in Phase 0)
Rationale: every historical failure is 8pm–midnight; budget for the
evening instead of fighting it.
- Breakfast: light, protein-forward (~25–30% of calories before 1pm).
- Lunch: real meal.
- ~3:30pm: protein snack — LOAD-BEARING SLOT, the late-spike defuser.
  Cabinet pings it; skipping it gets flagged same-day.
- Dinner ~7:00–7:30: the day's biggest meal. Locked by morning; grocery/
  prep logistics handled at the 2pm horizon, not at 6:30.
- Planned evening snack slot (~150–250 cal): pre-chosen, in the apartment,
  visible. Evening eating is in the budget, on purpose.
- Trainer days (Tue/Fri): shift dinner and protein to bracket the session.

## Evening — the flagship program (7:00–11:00)
The vacuum gaming left is filled by named blocks, chosen at the MORNING
brief (decisions made at 8am survive; decisions deferred to 8pm die):
1. OPS BLOCK (20–40 min, right after dinner): one chore or errand from
   Cabinet's list — the walk-downstairs energy pointed at something.
   Respects the ankle budget.
2. MAIN BLOCK (60–120 min): ONE of — build (Cabinet, projects, code),
   guitar practice (owns one; hands-busy blocks double as craving
   suppression, PLAYBOOK P10), league night, social (Zach/Jeff, family,
   a date), out-of-apartment activity, or intentional leisure (a chosen
   film/show/game — chosen, not drifted into). Out-of-apartment or human-contact blocks ≥ 2–3×/week
   (charter: scaffolding points outward).
3. Weed slot: default AFTER dinner and after ops block, not before
   (experiment E2 — timing vs. snacking/sleep).
4. WIND-DOWN at 10:30: screens off. Ten minutes of stretching (ankle
   protocol + hips/back). Current book + reading light. Cabinet maintains
   the reading queue (epic/literary fantasy; he's read the canon — queue
   accordingly). Lights target ~11:15.

Craving protocol (any time it hits): Ben pings Cabinet → damage-control
register: one concrete move (the stocked counter-snack), seltzer,
15-minute delay before any ordering decision, brief redirect to tonight's
block. Log the event + what worked → PLAYBOOK P4 ranking.

## Weekly
- Mon morning: yoga. Stage A (now): the morning floor protocol IS a
  home yoga flow, Cabinet-delivered daily. Stage B: studio Monday class
  resumes at 265 lb or six weeks in, whichever first — Cabinet unpauses
  the membership and books it; Ben shows up. (plans/health.md leg 3.)
- Tue/Fri: trainer (fixed, sacred — Cabinet plans around, never over).
- League nights in season (kickball, darts): protected social structure.
- Sunday evening: WEEKLY REVIEW (counsel register, big-model route):
  trend vs. plan, adherence, ankle load, experiments read out, TUNING
  changes, next week's headline target, plan amendments. The week's
  finish line (P3).

## Social-night variant (going out is a feature, not a breach)
Nights out with the crew are part of the life being built — the plan
bends around them instead of breaking on them. When one's on the
calendar (or declared same-day): eat a real protein-forward meal BEFORE
going out; the day's calories pre-shift to make room; no tracking
expected mid-night — one sentence or photo after is plenty; next morning
is a completely normal morning (weigh-in, brief, zero commentary beyond
the log). Alcohol and weed get logged like any variable. A big night
costs that day. It never costs the week.

## Degraded mode (chaos days)
When a day goes sideways — work crunch, travel chaos, a rough night —
the system asks for exactly one signal: a morning weight OR one sentence
OR one photo. That's a held day. Days-with-any-signal is the metric
Cabinet defends (P9); three signal-less mornings triggers a warm
reach-out, never an audit.

## Travel / vacation variant
Protect three things only: morning weight+mood log when feasible, protein
floor, and the wind-down/reading ritual. Everything else relaxes without
comment. Re-entry brief on return day rebuilds the structure; no
catch-up guilt, the trend line absorbs trips.
