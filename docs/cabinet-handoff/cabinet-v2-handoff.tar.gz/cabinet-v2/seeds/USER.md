# USER — Ben

Distilled from Ben's own account, July 2026. Corrections happen through
living contact: he says it's wrong or stale, Cabinet updates the file.

## Snapshot
- Ben, 39 (b. Dec 1986, Columbus OH). East Village, NYC. 
- Senior SWE at Summus Global (NYC health tech, ~70 ppl): React Native +
  AI-enablement dual mandate; reports to Sanders (CTO, former colleague).
  ~2 years in; good job with old friends after a bad chapter (below).
- Cornell ChemE '09. High-cognitive, elite test-taker, career
  procrastinator who performs on deadline.
- ~280 lb (trend ~277) at 6'0" (5'11.5" rounded up), right-ankle
  limitation (below). Strength training with a private trainer Tue/Fri,
  ~2 years, ~4 sessions missed total.

## Family
- Father: Brian. Died March 2015, age 57 — V-fib on a trip hike, ~18 months
  after a heart attack. Wealth manager (Ohio Co. → KeyBank → UBS), Columbus
  working-class origins, OSU. Larger-than-life: family's emotional engine,
  beloved by clients, charity cyclist ~4,000 mi/yr — and lifelong zero
  control of diet (the after-work snack ritual, road fast food). Ben was 28;
  the loss shaped his early 30s. The active-but-uncontrolled-diet model is
  Ben's inheritance; this project is its inversion. NEVER used as leverage.
- Mother: Mary. Retired RN, ~35 years, longest in cardiac. Youngest of 6
  from Brighton, NY. Moved from Ohio to East Northport, Long Island (a
  few years after Beth's NYC move) — an LIRR ride away.
- Sister: Beth, 3 years younger. Northwestern D1 swimmer; IBM → LinkedIn;
  moved to NYC ~a year or two after their dad died. Married John —
  Queens born-and-raised, FDNY firefighter, drives the engine for his
  house. Two daughters: Margaret "Maggie" and Allison "Allie." All in
  East Northport (near mom). Fought as kids, close as adults; Ben spends
  time with them. Family = ready-made out-of-apartment blocks; get
  birthdays + visit cadence into contact rows (Cabinet task).
- Extended: large Catholic families both sides (dad 1 of 5, mom 1 of 6).

## Health history
- Weight arc: ~180 (HS) → 190–200 (college/20s) → 210–215 (late 20s,
  athletic) → slow creep through 30s → ~280 (early 2025) → 239 (Feb 2026,
  Dry January + religious tracking) → ~280 again (July 2026). See "The
  2026 swing" below — it is the most load-bearing fact on file.
- Right ankle: 5mm osteochondral lesion, talus. Microfracture 2014 (failed
  as that procedure tends to); OATS at HSS ~2022–23, possibly rushed
  return-to-weight-bearing; degrading again past ~3 years. NO running
  sports (soccer/frisbee identity lost). Walking must be budgeted; evening
  and weather-linked aching; flares after heavy walking days.
- Cardiac family history (father: MI + fatal arrhythmia at 57). Baselines
  needed: BP, resting HR, bloodwork. Height: NOT ON FILE — get it.
- Weed: current, heavy, self-described "for better or worse." In scope,
  first-class variable.
- Sports history: soccer, basketball, ultimate; "plodding, methodical
  pace" (his words, inherited from dad, worn with some affection).

## The 2026 swing (most important data point on file)
Dry January 2026: quit alcohol AND weed for the month, tracked food
religiously → 239 lb at ~6 weeks. Capability is PROVEN — this is not a
person who can't lose weight. The collapse chain, in order: resumed both
substances → a demoralizing date (emotional hit) → fun social spring/
summer + AI-work crunch → tracking stopped → +40 lb in ~5 months. Shape:
cliff, not drift. The system was all-or-nothing (perfect abstinence +
perfect logging) and one crack cascaded. The ONLY structure that survived
untouched: the trainer. Design consequence: durability > intensity;
everything must degrade gracefully (PLAYBOOK P9, plans/health.md
relapse-resistance).
- Alcohol: first-class tracked variable alongside weed. Heavy in 20s;
  extended sober stretch early 2026; current pattern = social,
  going-out-heavy season with the crew. Track, reflect patterns; no
  editorializing, no prescriptions.

## Movement assets
- Yoga: real history — learned from two friends during their instructor
  training (social origin, very Ben), attended their studio, lapsed
  during COVID, bought a membership Jan 2026 with a Monday-morning plan
  → derailed after ONE session by a Citi Bike crash (wrist). Wrist now
  recovered to pain-free planks/pushups (~July 2026). Membership PAUSED;
  agreed plan: home flow now (as the morning protocol), studio re-entry
  at 265 lb or six weeks in, whichever first (date backstop is
  deliberate — felt-gates drift).
- Home gym gear in the apartment: inventory pending (Cabinet ops task —
  Ben photographs, Cabinet catalogs).
- Guitar: owns one (college era), wants to learn. Keyboard/piano desired
  eventually (deferred — see milestones).

## Food history
- Family of origin never cooked (frozen Market Day catalog food; mom
  couldn't cook, dad had no time). Food-skills-and-defaults gap, not a
  willpower gap. Inherited dad's snack-attack pattern.
- Current failure loop: unstructured evenings + boredom + weed →
  Seamless/Grubhub, the downstairs bodega, apartment grazing. 8pm–midnight
  is where the diet loses.
- Assets: enjoys cooking, decent kitchen (Instant Pot, air fryer), already
  tracks macros (prefers plain lists, no tables/commentary).

## Structure pattern (the master key — see PLAYBOOK P1/P2)
Thrives under external, scheduled, social structure; self-generated
structure doesn't form. Normalizes slow drift (stayed 3.5 years at a
micromanaging startup as its "dream job" wrapper decayed; decade weight
creep). Deadline-driven; open-ended tasks die quietly.

## Evenings (the keystone problem)
Gaming filled 6pm–3am for years; quit cold ~6 months ago when the PC died
— a deliberate clean break, and it stuck. Nothing replaced the structure:
current default is desk + YouTube/X + eating. He does NOT want the gaming
back; he wants the vacuum filled with intentional structure.

## People
- Core crew: Zach (33) + girlfriend Lindsay; Jeff (30) + wife Noel. Via
  kickball ~3 summers ago; now kickball + darts leagues, ski trip,
  Berkshires July 4, weekly hangs. Younger than Ben; great fit.
- Best friend moved to Philadelphia (a real loss in the isolation years).
- History: shy kid; church youth group + summer camp (staffed it for
  years) opened him up. Eagle Scout (earned; paperwork never filed —
  very Ben).
- Romantic: first gf senior yr HS. College: one controlling/manipulative
  relationship, then one that ended in being cheated on (discovered
  messily). His own account: lost trust, essentially single by default
  through his entire 20s–30s. Current cycle: ~one date every 6–12 months
  → sometimes fine, rarely more than 1–2 follow-ups → discouragement →
  swears off apps for months. His own mechanism: body discomfort — not
  fear of her judgment, but not feeling at home in his own skin or
  clothes, so he can't relax into being himself. A recent rough date:
  asked about his dating history, he spiraled into the losses (dad,
  ankle) — kind response, no second date; it stung and preceded the 2026
  collapse. Slow-rebuild domain — see PLAYBOOK P7 (aftermath is the
  failure unit; the story is preparable; clothes that fit NOW).

## Work history (compressed)
Capital IQ (first job, DB eng, met the crew he works with now) → mobile
eng across TickPick, Mark43 (COVID era), WeWork (watched the implosion),
LeagueApps → 3.5 years as first senior eng at a small startup under a
micromanaging founder (the bad chapter; isolating, work+weed+junk-food
years) → Summus (current, good). Deep AI tooling experience; built
production multi-agent systems; uses Claude Code daily.

## Reader
Lifelong epic/literary fantasy + sci-fi: Wheel of Time, Tolkien, GRRM,
Dune, Ender's Game; favorite: Altered Carbon. Has read the canon — the
reading queue should assume it.

## Money
Dad's financial-planning legacy; Ben follows macro/finance topics.
Current picture not yet on file — develop in counsel, then plans/money.md.

## Open gaps (ask naturally, don't interview)
BP/resting HR; recent bloodwork; dietary constraints (never asked —
needs real rows or confirmedNone sentinel); home gym inventory (photo →
catalog); daily logistics (wake time, office days vs. WFH, commute, work
hours — RHYTHM's anchor times); weekend shape (RHYTHM is weekday-built;
weekends need their own default); niece birthdays + family visit cadence
(→ contact rows); trainer's name; financial picture (counsel session);
career direction — where Ben actually wants the AI wave to take him
(counsel session, big-model route; never actually discussed, only the
history); ortho follow-up cadence at HSS.
