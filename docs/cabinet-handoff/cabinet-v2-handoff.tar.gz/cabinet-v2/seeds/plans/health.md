# PLAN: health — weight, food, training, ankle

The reasoning layer. Goal-table rows are projections of this file; when
this file changes, the rows change. Review triggers at bottom. All numbers
carry bands and get recalibrated against observed data — the trend line
outranks every formula.

## The strategic picture
February 2026 settled the capability question: Dry January + religious
tracking → 239 lb. Ben can lose weight, fast, when a system is intact.
Feb–Jul settled the design question: that system was all-or-nothing, and
one crack (substances back → one bad date → busy season → tracking
stopped) cascaded to +40 lb in five months. So this plan's objective is
NOT maximum rate — it is a loss system that survives contact with Ben's
actual life: drinking weekends, emotional hits, work crunches, fun
seasons. Durability > intensity. Deliberately slower than February,
permanently unlike February. (See relapse resistance below; PLAYBOOK P9.)

Ben inherited a model where activity covers for diet; the ankle removed
the activity half and the diet half was never built. The plan runs on
three legs, in priority order:
1. FOOD STRUCTURE (the whole game): late-weighted meal pattern, decided-in-
   advance dinners, budgeted evening snack, logistics won at the 2pm
   horizon. See RHYTHM.
2. STRENGTH (already solved): trainer Tue/Fri owns programming. Cabinet
   never programs lifting; it feeds the trainer context (weight trend,
   sleep, flares) via Ben and plans nutrition/recovery around sessions.
3. NON-IMPACT MOVEMENT (rebuild carefully): within ankle budget. Yoga,
   in two stages, Ben's call with one structural fix:
   - STAGE A (now): home yoga folded INTO the morning floor protocol —
     it IS the 10-minute flow, delivered and tracked by Cabinet each
     morning (never left as a self-administered routine; those don't
     hold — P1). Wrist cleared for planks/pushups.
   - STAGE B (studio, membership currently paused): re-entry at 265 lb
     OR six weeks from Phase 0 start, WHICHEVER COMES FIRST. The date
     backstop exists because "when I'm feeling good again" is exactly
     the deferral shape P7 flags — a felt-gate with no clock becomes
     never. At the trigger: Cabinet unpauses the membership and books
     the Monday class; Ben just shows up.
   Home gym gear gets cataloged in Phase 0 (Cabinet ops task) and folded
   in where useful. Stationary bike is a possible Phase 2 addition, not
   a Phase 1 decision.

Weight loss is also the ankle plan: every pound off is multiple pounds of
per-step joint load. The flywheel: lighter → ankle calmer → more movement
possible → mood and evenings improve → adherence easier. Everything
compounds; nothing sprints.

## Phases
- PHASE 0 — instrument (2 weeks): log everything, change little. Morning
  weight, meals as macros, craving events, weed timing, alcohol (drinks +
  context), sleep score, ankle ache (0–10, evenings), walking load. Purpose: real TDEE from observed
  trend-vs-intake (beats any formula), and baselines. Get: height, BP,
  resting HR; book bloodwork if none in past year (family cardiac history
  — this is instrumentation, not alarm; a $30 BP cuff earns its slot).
- PHASE 1 — the first 25 (to ~255): target 1.25–1.75 lb/wk. At Ben's size
  this is conservative-side and sustainable; expect a fast first-week
  water drop, then the band. ETA ~end of 2026. Deliberate diet break
  (maintenance week) roughly every 8 weeks or around trips.
- PHASE 2 — 255 → 230: same machinery, slower band (~1 lb/wk), more diet
  breaks. Nothing new should need inventing; Phase 2 is Phase 1 continued.
- REASSESS AT 230: with two+ years of lifting mass, the healthy-great
  range is probably 215–235, not the 185–200 of pre-lifting eras — but
  that's a decision for a much lighter Ben with a year more data, standing
  in a different body. Decide there, not here.

## Provisional numbers (Phase 0 calibrates all of these)
- Height on file: 6'0" (5'11.5", rounds up — noted with affection).
- TDEE estimate: BMR ≈ 2,200 (Mifflin-St Jeor at 280/6'0"/39) × ~1.3–1.4
  activity (sedentary-plus, 2× lifting, budgeted walking) ≈ 2,900–3,100.
  Observed trend-vs-intake in Phase 0 replaces this formula within ~3
  weeks; the formula just sets the opening band.
- Calories: ~2,250–2,400/day → ~1.25–1.75 lb/wk expected. Adjust from
  trend, not from formulas, starting week 3.
- Protein: 180–200 g/day (≈0.7–0.8 g/lb of eventual goal weight; also the
  satiety lever for the evening war). This likely becomes THE daily
  headline metric — protein hit + inside calorie band = a won day.
- Meal pattern: late-weighted per RHYTHM (this pattern IS experiment E1's
  superset; two-week read, then commit or adjust).

## Ankle protocol
- Walking budget: TBD in Phase 0 from flare data (ache ≥6 or next-morning
  ache = over budget the prior day).
- Daily: the morning mobility flow + evening stretch include the ankle
  circuit (ROM, calf/posterior chain, band work) — details to build with
  trainer input.
- Flare response: swap ops-block errands for in-apartment tasks, note
  weather, no heroics.
- Standing question for Ben's ortho (Cabinet preps the data): follow-up
  cadence at HSS, and what the flare pattern since ~2023 changes, if
  anything. Cabinet tracks; doctors decide.

## Relapse resistance (the actual hard problem)
The floors — four things that survive ANY week, no exceptions needed:
1. Morning weigh-in (10 seconds; happens hungover, happens on vacation).
2. Protein floor (even on a chaos day, protein gets prioritized first).
3. Trainer Tue/Fri (already indestructible; the load-bearing wall).
4. Wind-down ritual (screens off, stretch, book — sleep protects
   everything else).
Everything above the floors is allowed to flex. A drinking weekend, a
skipped day, an untracked dinner: absorbed by design, not exceptions to
be forgiven.
- Collapse detection: 3 consecutive mornings without any signal → warm
  same-week reach-out. Not an audit — the February collapse ran ~5 months
  undetected; the new maximum is 3 days.
- Emotional-hit protocol: after a known disappointment (a bad date, a
  rough work stretch), the next 72 hours are flagged high-risk (the Feb
  chain started exactly here). Cabinet quietly tightens: evening blocks
  pre-set, counter-snack stocked, one extra check-in. Support, not
  surveillance.
- Re-entry protocol: after any lapse of any length — no makeup work, no
  confession, no reviewing what was missed. The trend line absorbs it.
  Day one starts with a normal morning brief, and the only backward
  reference permitted is data.
- Alcohol + weed: both logged as first-class variables (timing, amount,
  correlations with snacking/sleep/morning mood). Cabinet tracks and
  reflects patterns; whether and how much are Ben's calls.

## Milestones (framing matters)
- The real frontier is 239 — February Ben. Waypoints down are "reclaims"
  until then; below 239 is genuinely new ground for this decade. Frame
  accordingly: beating February Ben slowly is the whole strategy.
- At 255 (Phase 1 complete): the keyboard gets bought. Piano was earned.
- NOW, not at a milestone: 2–3 clothing items that fit the current body.
  Feeling at home in clothes is purchasable this week and it's
  confidence infrastructure for everything, dating included. Waiting to
  deserve clothes is backwards.

## Review triggers (drift-detector duty, PLAYBOOK P2)
- Trend flat or up 2 consecutive weeks in a loss phase → Sunday agenda,
  mandatory: adherence problem vs. calorie-target problem, decided with
  data, plan amended.
- 3+ craving events/week two weeks running → evening structure isn't
  holding; redesign the block, don't blame the operator.
- Ankle ache ≥6 twice in a week → cut walking budget 25%, review load.
- 3 signal-less mornings → warm reach-out (see relapse resistance); a
  full signal-less week → counsel conversation about friction, not
  compliance.
- Every 8 weeks regardless: full plan re-read at Sunday review.
